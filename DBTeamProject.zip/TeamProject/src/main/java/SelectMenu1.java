import java.sql.*;

public class SelectMenu1 {
    public SelectMenu1() {
        try {
            
            // 데이터베이스 연결
        	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamdb?severTimezone=UTC", "testuser", "testpw");
			System.out.println("DB connect success!");
			Statement stmt = conn.createStatement();

            // 사용자로부터 입력 받기
            java.util.Scanner scanner = new java.util.Scanner(System.in);
            System.out.print("Enter the location of the agency: ");
            String location = scanner.nextLine();

            // 뷰 생성 쿼리 작성
            String createViewQuery = "CREATE OR REPLACE VIEW SingerNamesView AS " +
                    "SELECT Singers.name FROM Singers JOIN Agencies ON Singers.agency = Agencies.name WHERE Agencies.location = ?";
            PreparedStatement createViewStmt = conn.prepareStatement(createViewQuery);
            createViewStmt.setString(1, location);
            createViewStmt.executeUpdate();

            // 뷰 조회 쿼리 작성 및 실행
            String selectViewQuery = "SELECT * FROM SingerNamesView";
            Statement selectViewStmt = conn.createStatement();
            ResultSet rs = selectViewStmt.executeQuery(selectViewQuery);

            // 결과 출력
            System.out.println("Singer names:");
            while (rs.next()) {
                String singerName = rs.getString("name");
                System.out.println(singerName);
            }

            // 연결 및 자원 해제
            rs.close();
            selectViewStmt.close();
            createViewStmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}

    
    

    





