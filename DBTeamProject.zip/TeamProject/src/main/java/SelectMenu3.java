import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectMenu3 {
	public SelectMenu3() {
		try {
			//DB연결(teamdb이용)
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamdb?serverTimezone=Asia/Seoul", 
							  "testuser","testpw");
			System.out.println("DB connect success!");
			Statement stmt = conn.createStatement();
			
			//Select문(aggregation function with group by)
			//현 차트 안에서 각 가수가 발매한 음원수를 추출하는 select문
			ResultSet rset=stmt.executeQuery("select singer,count(*) from songs group by singer");
			
			//select문 결과 출력
			while(rset.next())
			{
				System.out.println("가수:"+rset.getString(1)+"  음원 수:"+rset.getString(2));
			}

		} catch (SQLException sqle) {
			System.out.println("SQLException" + sqle);
		}
		
	}

}
