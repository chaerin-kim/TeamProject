import java.util.Scanner;

public class MainMenu {
	
	public static void main(String[]args) {
		
		int exit=0;
		Scanner input=new Scanner(System.in);
		
		while(exit==0) {
			System.out.println("####### Music Chart DB #######");
			System.out.println("---- Please select a menu ----");
			System.out.println("1. SelectMenu1");
			System.out.println("2. SelectMenu2");
			System.out.println("3. SelectMenu3");
			System.out.println("4. InsertMenu");
			System.out.println("5. UpdateMenu");
			System.out.println("6. DeleteMenu");
			System.out.println("0. exit");
			System.out.print("menu:");
			
			int menu=input.nextInt();
			
			switch(menu) {
			case 1:
				SelectMenu1 a=new SelectMenu1();
				break;
			case 2:
				SelectMenu2 b=new SelectMenu2();
				break;
			case 3:
				SelectMenu3 c=new SelectMenu3();
				break;
			case 4:
				InsertMenu d=new InsertMenu();
				break;
			case 5:
				UpdateMenu e=new UpdateMenu();
				break;
			case 6:
				DeleteMenu f=new DeleteMenu();
				break;
			case 0:
				System.out.println("exit!");
				exit=1;
				break;
			default:
				System.out.println("메뉴가 존재하지 않습니다. 다시 선택해주세요!");
				System.out.println("");
				continue;
			}
			
			System.out.println("");
			
		}
		
	}
	

}
