import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class UpdateMenu {
    public UpdateMenu() {
        try {
            // JDBC 드라이버 로드
        	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamdb?severTimezone=UTC", "testuser", "testpw");
			System.out.println("DB connect success!");
			Statement stmt = conn.createStatement();

            // 사용자로부터 입력 받기
            java.util.Scanner scanner = new java.util.Scanner(System.in);
            System.out.print("Enter the name of the singer: ");
            String singerName = scanner.nextLine();

            // 가수의 numMembers 값을 1 증가시키는 쿼리 작성 및 실행
            String query = "UPDATE Singers SET numMembers = numMembers + 1 WHERE name = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, singerName);
            int rowsAffected = pstmt.executeUpdate();

            // 업데이트 결과 출력
            if (rowsAffected > 0) {
                String selectQuery = "SELECT numMembers FROM Singers WHERE name = ?";
                PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
                selectStmt.setString(1, singerName);
                ResultSet rs = selectStmt.executeQuery();
                if (rs.next()) {
                    int updatedNumMembers = rs.getInt("numMembers");
                    System.out.println("Successfully updated numMembers for singer: " + singerName);
                    System.out.println("Updated numMembers value: " + updatedNumMembers);
                }
                rs.close();
                selectStmt.close();
            } else {
                System.out.println("No rows affected. Singer not found.");
            }

            // 연결 및 자원 해제
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}