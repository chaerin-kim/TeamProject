import java.sql.*;
import java.util.Scanner;

public class InsertMenu {
	public InsertMenu() {
		
		try {
			//연결 확인
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamdb?severTimezone=UTC", "testuser", "testpw");
			System.out.println("DB connect success!");
			Statement stmt = conn.createStatement();
			
			//input할 내용
			Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the name of the Agencies: ");
            String  AgenciesName = scanner.nextLine();
            
            // INSERT 문 실행
            String sql = "INSERT INTO Agencies (name) VALUES (?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, AgenciesName);
            statement.executeUpdate();
            
            System.out.println("Agencies inserted successfully.");
            
            // 끝
            statement.close();
            conn.close();
            
		}catch(SQLException ex) {
			System.out.println("SQLException"+ ex);
		}
	}
}

