import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteMenu {
	public DeleteMenu() {
		
		try {
			
			Scanner input=new Scanner(System.in);
			//DB연결(teamdb이용)
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamdb?serverTimezone=Asia/Seoul", 
					          "testuser","testpw");
			System.out.println("DB connect success!");
			Statement stmt = conn.createStatement();
			
			//사용자에게 삭제할 노래 제목 입력받기
			System.out.print("Please enter the title of the song you want to delete:");
			String title=input.nextLine();
			
			try {
				//1.삭제될 노래를 제외한 나머지 노래들 순위 조정
				//삭제할 노래의 순위 추출
				int rank=0;
				String sql="select ranking from ranking where song='"+title+"'";
				ResultSet rset=stmt.executeQuery(sql);
				if(rset.next())
				{
					rank=rset.getInt(1);
				}
				else{
					System.out.println("노래가 존재하지 않습니다");
					System.exit(1);
				};
				//삭제할 노래를 제외한 나머지 노래들의 ranking 조정
				PreparedStatement pStmt2=conn.prepareStatement("update ranking set ranking=ranking-1 where ranking>?");
				pStmt2.setInt(1, rank);
				pStmt2.executeUpdate();
				
				//2.선택한 노래 삭제 진행
				PreparedStatement pStmt= conn.prepareStatement("delete from songs where title=?");
				pStmt.setString(1,title);
				int result=pStmt.executeUpdate();
				
				if(result>0) {System.out.println("delete success!");}
				
			}catch(SQLException e) {
				e.printStackTrace();
			}

		} catch (SQLException sqle) {
			System.out.println("SQLException" + sqle);
		}
	}
}
