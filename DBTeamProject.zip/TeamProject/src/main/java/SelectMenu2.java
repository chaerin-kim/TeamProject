
import java.sql.*;
import java.util.Scanner;

public class SelectMenu2 {
	public SelectMenu2() {
		
		try {
			//연결 확인
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamdb?severTimezone=UTC", "testuser", "testpw");
			System.out.println("DB connect success!");
			Statement stmt = conn.createStatement();
			
            // Singer 입력하면 Agency 를 알 수 있음
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the Singer to search: ");
            String inputName = scanner.nextLine();
            
            // 뷰 생성
            String createViewQuery = "CREATE OR REPLACE VIEW view_singer_agency AS SELECT singers.name, agencies.name AS agency_name FROM singers JOIN agencies ON singers.agency = agencies.name";
            PreparedStatement createViewStatement = conn.prepareStatement(createViewQuery);
            createViewStatement.executeUpdate();

            // 조인과 뷰를 사용한 검색
            String searchQuery = "SELECT name, agency_name FROM view_singer_agency WHERE name LIKE ?";
            PreparedStatement searchStatement = conn.prepareStatement(searchQuery);
            searchStatement.setString(1, "%" + inputName + "%");
            ResultSet resultSet = searchStatement.executeQuery();

            // 검색 결과 출력
            while (resultSet.next()) {
                String singerName = resultSet.getString("name");
                String agencyName = resultSet.getString("agency_name");
                System.out.println("Singer: " + singerName + ", Agency: " + agencyName);
            }

            // 끝
            resultSet.close();
            searchStatement.close();
            createViewStatement.close();
            conn.close();

				
		
        } catch (SQLException sqle) {
            System.out.println("SQLException: " + sqle);
        }

    }
}








